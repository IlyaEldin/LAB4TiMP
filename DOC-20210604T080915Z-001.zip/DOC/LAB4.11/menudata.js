var menudata={children:[
{text:"Титульная страница",url:"index.html"},
{text:"Классы",url:"annotated.html",children:[
{text:"Классы",url:"annotated.html"},
{text:"Алфавитный указатель классов",url:"classes.html"},
{text:"Члены классов",url:"functions.html",children:[
{text:"Указатель",url:"functions.html"},
{text:"Функции",url:"functions_func.html"},
{text:"Переменные",url:"functions_vars.html"}]}]},
{text:"Файлы",url:"files.html",children:[
{text:"Файлы",url:"files.html"},
{text:"Список членов всех файлов",url:"globals.html",children:[
{text:"Указатель",url:"globals.html"},
{text:"Функции",url:"globals_func.html"}]}]}]}
